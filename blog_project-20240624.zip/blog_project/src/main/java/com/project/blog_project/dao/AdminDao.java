package com.project.blog_project.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

@Repository
public class AdminDao {
    @Autowired
    JdbcTemplate jt;
    public List<Map<String,Object>> codeCategorySelect(){
        String sqlStmt = "select category_id as categoryId, category_nm as categoryNm from code_category";
        return jt.queryForList(sqlStmt);
    }
    public int idSelect(String category){
        String sqlStmt = "select count(*) from code_mst where code_id like '"+category+"%'";
        int categoryCnt = jt.queryForObject(sqlStmt,Integer.class);
        return categoryCnt;
    }
    public void codeInsert(String category, String codeId, String codeNm, String codeDesc){
        String sqlStmt = "insert into code_mst(code_cat,code_id,code_nm,code_desc) values(?,?,?,?)";
        jt.update(sqlStmt,category,codeId,codeNm,codeDesc);
    }
    public int codeDupCheck(String codeNm){
        String sqlStmt = "select count(*) from code_mst where code_nm = ?";
        return jt.queryForObject(sqlStmt, Integer.class,codeNm);
    }
    public List<Map<String, Object>> codeSelect(){
        String sqlStmt = "select a.seq as seq,a.code_id as codeId, a.code_cat as codeCat, b.category_nm as categoryNm, ";
               sqlStmt += " a.code_nm as codeNm, a.code_desc as codeDesc, ";
               sqlStmt += " a.code_stat as codeStat, a.reg_dt as regDt, a.modify_dt as modifyDt ";
               sqlStmt += "from code_mst a, code_category b ";
               sqlStmt += "where a.code_cat = b.category_id ";
               sqlStmt += "order by code_cat ";
        return jt.queryForList(sqlStmt);
    }
    public List<Map<String,Object>> selectCodeStat(){
        String sqlStmt = "select code_id as codeId, code_nm as codeNm from code_mst where code_cat = '3'";
        return jt.queryForList(sqlStmt);
    }
    public void codeStatUpdate(String seq, String stat){
        String sqlStmt = "update code_mst set code_stat = ? where seq = ?";
        jt.update(sqlStmt,stat,seq);
    }
    public List<Map<String,Object>> codeUpdateForSelect(String seq){
        
        String sqlStmt = "select seq, code_id as codeId, code_cat as codeCat, ";
               sqlStmt += "code_nm as codeNm, code_desc as codeDesc, ";
               sqlStmt += "code_stat as codeStat from code_mst where seq = '"+seq+"'";
        return jt.queryForList(sqlStmt);
    }
    public void adminCodeUpdateAction( String seq,
                                       String stat,
                                       String codeNm,
                                       String codeDesc,
                                       String codeCat){
        String sqlStmt = "update code_mst set code_nm = ?, ";
               sqlStmt += "code_stat = ?, code_desc = ?, code_cat = ? where seq = ?";
        jt.update(sqlStmt,codeNm,stat,codeDesc,codeCat,seq);
    }
    public List<Map<String,Object>> selectCodeCategory(){
        String sqlStmt = "select seq, category_id as categoryId, category_nm as categoryNm from code_category";
        return jt.queryForList(sqlStmt);
    }
    public int categoryCnt(){
        String sqlStmt = "select max(seq) from code_category";
        return jt.queryForObject(sqlStmt, Integer.class);
    }
        
    public void adminCodeCategoryInsertAction(int categoryId,String category){
        String sqlStmt = "insert into code_category(category_id, category_nm) values(?,?)";
        jt.update(sqlStmt, categoryId,category);
    }

}
