package com.project.blog_project.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.*;
@Repository
public class BlogDao {
    @Autowired
    JdbcTemplate jt;
    public List<Map<String, Object>> codeSelect(){
        String sqlStmt = "select code_id, code_nm from code";
        return jt.queryForList(sqlStmt);
    }
    public void insert(String subject, String title, String content, String memberId){
        String sqlStmt = "insert into board(subject, title, content, writer) ";
              sqlStmt += "values(?,?,?,?)";
        jt.update(sqlStmt,subject,title,content,memberId);
    }
    public List<Map<String,Object>> select(){
        String sqlStmt = "";
        sqlStmt += "select a.seq as seq, ";
        sqlStmt += "a.title as title, ";
        sqlStmt += "a.subject as subject, ";
        sqlStmt += "a.likeCnt as likeCnt, ";
        sqlStmt += "a.writer as writer, ";
        sqlStmt += "b.memberScore as memberScore, ";
        sqlStmt += "a.memberNm as memberNm, ";
        sqlStmt += "a.memberEmail as memberEmail ";
        sqlStmt += "from (select a.seq as seq, ";              
        sqlStmt += "a.title as title, ";
        sqlStmt += "c.code_nm as subject, ";
        sqlStmt += "a.like_cnt as likeCnt, ";
        sqlStmt += "a.writer as writer, ";
        sqlStmt += "b.member_nm as memberNm, ";
        sqlStmt += "b.member_email as memberEmail ";
        sqlStmt += "from board a, member b, code c ";
        sqlStmt += "where a.writer = b.member_id ";
        sqlStmt += "and a.subject = c.code_id) a ";
        sqlStmt += "left join (select ifnull(b.score,0) as memberScore, ";
        sqlStmt += "a.member_id as writer ";
        sqlStmt += "from member a ";
        sqlStmt += "left join (select a.writer, a.cnt_score + b.like_score as score ";
        sqlStmt += "from (select writer, count(*)*5 as cnt_score ";
        sqlStmt += "from board ";
        sqlStmt += "group by writer) a, ";
        sqlStmt += "(select writer, sum(like_cnt)*2 as like_score ";
        sqlStmt += "from board ";
        sqlStmt += "group by writer) b ";
        sqlStmt += "where a.writer = b.writer) b ";
        sqlStmt += "on  a.member_id = b.writer ";
        sqlStmt += "where a.member_id <> 'admin') b ";
        sqlStmt += "on a.writer = b.writer";

        return jt.queryForList(sqlStmt);
    }
    public List<Map<String, Object>> detail(String seq){
        String sqlStmt = "select a.content as content, ";
              sqlStmt += "a.seq as seq, "; 
              sqlStmt += "a.title as title, ";
              sqlStmt += "b.member_nm as memberNm, ";
              sqlStmt += "c.code_nm as codeNm, ";
              sqlStmt += "a.reg_dt as regDt, ";
              sqlStmt += "a.modify_dt as modifyDt, ";
              sqlStmt += "a.modify_hst as modifyHst "; 
              sqlStmt += "from board a, member b, code c ";
              sqlStmt += "where a.seq = '"+seq+"' "; 
              sqlStmt += "and a.writer = b.member_id "; 
              sqlStmt += "and a.subject = c.code_id ";
        return jt.queryForList(sqlStmt);
    }
    public List<Map<String, Object>> detailComment(String seq){
        String sqlStmt = "select b.member_nm as memberNm ,"; 
               sqlStmt += "a.comment as comment, "; 
               sqlStmt += "a.reg_dt as regDt ";
               sqlStmt += "from board_comment a, member b ";
               sqlStmt += "where board_id = '"+seq+"' ";
               sqlStmt += "and a.member_id = b.member_id ";
        return jt.queryForList(sqlStmt);
    }
    public void commentInsert(String boardId, String comment, String memberId){
        String sqlStmt = "insert into board_comment(board_id, comment, member_id) ";
              sqlStmt += "values(?,?,?)";
        jt.update(sqlStmt,boardId,comment,memberId);              
    }
    public List<Map<String,Object>> detailRegDt(String seq){
        String sqlStmt = "select reg_dt as regDt from board where seq ='"+seq+"'";
        return jt.queryForList(sqlStmt);
    }
    public void update(String seq, 
                       String subject, 
                       String title, 
                       String content,
                       String currentDate){
        String sqlStmt = "update board set subject = ?, title = ?, content = ?, modify_dt = ?, modify_hst = 1 where seq = ?";
        jt.update(sqlStmt,subject, title, content,currentDate ,seq);
    }
    public List<Map<String,Object>> searchSubject(String subject){
        String sqlStmt = "";
        sqlStmt += "select a.seq as seq, ";
        sqlStmt += "a.title as title, ";
        sqlStmt += "a.subject as subject, ";
        sqlStmt += "a.likeCnt as likeCnt, ";
        sqlStmt += "a.writer as writer, ";
        sqlStmt += "b.memberScore as memberScore, ";
        sqlStmt += "a.memberNm as memberNm, ";
        sqlStmt += "a.memberEmail as memberEmail ";
        sqlStmt += "from (select a.seq as seq, ";              
        sqlStmt += "a.title as title, ";
        sqlStmt += "c.code_nm as subject, ";
        sqlStmt += "a.like_cnt as likeCnt, ";
        sqlStmt += "a.writer as writer, ";
        sqlStmt += "b.member_nm as memberNm, ";
        sqlStmt += "b.member_email as memberEmail ";
        sqlStmt += "from board a, member b, code c ";
        sqlStmt += "where a.writer = b.member_id ";
        sqlStmt += "and a.subject = c.code_id) a ";
        sqlStmt += "left join (select ifnull(b.score,0) as memberScore, ";
        sqlStmt += "a.member_id as writer ";
        sqlStmt += "from member a ";
        sqlStmt += "left join (select a.writer, a.cnt_score + b.like_score as score ";
        sqlStmt += "from (select writer, count(*)*5 as cnt_score ";
        sqlStmt += "from board ";
        sqlStmt += "group by writer) a, ";
        sqlStmt += "(select writer, sum(like_cnt)*2 as like_score ";
        sqlStmt += "from board ";
        sqlStmt += "group by writer) b ";
        sqlStmt += "where a.writer = b.writer) b ";
        sqlStmt += "on  a.member_id = b.writer ";
        sqlStmt += "where a.member_id <> 'admin') b ";
        sqlStmt += "on a.writer = b.writer ";
        sqlStmt += "where a.subject = '"+subject+"'";

        return jt.queryForList(sqlStmt);
    }
    public List<Map<String,Object>> searchContent(String q){
        String sqlStmt = "";
        sqlStmt += "select a.seq as seq, ";
        sqlStmt += "a.title as title, ";
        sqlStmt += "a.subject as subject, ";
        sqlStmt += "a.likeCnt as likeCnt, ";
        sqlStmt += "a.writer as writer, ";
        sqlStmt += "b.memberScore as memberScore, ";
        sqlStmt += "a.memberNm as memberNm, ";
        sqlStmt += "a.memberEmail as memberEmail ";
        sqlStmt += "from (select a.seq as seq, ";              
        sqlStmt += "a.title as title, ";
        sqlStmt += "a.content as content, ";
        sqlStmt += "c.code_nm as subject, ";
        sqlStmt += "a.like_cnt as likeCnt, ";
        sqlStmt += "a.writer as writer, ";
        sqlStmt += "b.member_nm as memberNm, ";
        sqlStmt += "b.member_email as memberEmail ";
        sqlStmt += "from board a, member b, code c ";
        sqlStmt += "where a.writer = b.member_id ";
        sqlStmt += "and a.subject = c.code_id) a ";
        sqlStmt += "left join (select ifnull(b.score,0) as memberScore, ";
        sqlStmt += "a.member_id as writer ";
        sqlStmt += "from member a ";
        sqlStmt += "left join (select a.writer, a.cnt_score + b.like_score as score ";
        sqlStmt += "from (select writer, count(*)*5 as cnt_score ";
        sqlStmt += "from board ";
        sqlStmt += "group by writer) a, ";
        sqlStmt += "(select writer, sum(like_cnt)*2 as like_score ";
        sqlStmt += "from board ";
        sqlStmt += "group by writer) b ";
        sqlStmt += "where a.writer = b.writer) b ";
        sqlStmt += "on  a.member_id = b.writer ";
        sqlStmt += "where a.member_id <> 'admin') b ";
        sqlStmt += "on a.writer = b.writer ";
        sqlStmt += "where a.content like '%"+q+"%'";
        return jt.queryForList(sqlStmt);
    }
    public List<Map<String,Object>> order(String orderMethod){
        String sqlStmt = "";
        sqlStmt += "select a.seq as seq, ";
        sqlStmt += "a.title as title, ";
        sqlStmt += "c.code_nm as subject, ";
        sqlStmt += "a.writer as writer, ";
        sqlStmt += "a.like_cnt as likeCnt, ";
        sqlStmt += "b.member_nm as memberNm, ";
        sqlStmt += "b.member_email as memberEmail ";
        sqlStmt += "from board a, member b ,code c ";
        sqlStmt += "where a.subject = c.code_id and a.writer = b.member_id  ";
        sqlStmt += "order by a.reg_dt ";
        sqlStmt += orderMethod;
        return jt.queryForList(sqlStmt);
    }
    public void like(String seq){
        String sqlStmt = "update board set like_cnt = like_cnt + 1 where seq = ?";
        jt.update(sqlStmt,seq);
    }
    public void delete(String seq){
        String sqlStmtForBoard = "delete from board where seq = ?";
        String sqlStmtForComment ="delete from board_comment where board_id = ?";
        jt.update(sqlStmtForBoard,seq);
        jt.update(sqlStmtForComment,seq);
    }
    public void dislike(String seq){
        String sqlStmt = "update board set dislike_cnt = dislike_cnt + 1 where seq = ?";
        jt.update(sqlStmt,seq);
    }
    public List<Map<String, Object>> adminDeltetList(){
        String sqlStmt = "";
        sqlStmt += "select seq, ";
        sqlStmt += "title, dislike_cnt as dislikeCnt, like_cnt as likeCnt from board ";
        sqlStmt += "where seq in (select a.seq ";
        sqlStmt += "from (select seq, dislike_cnt - like_cnt as cnt ";
        sqlStmt += "from board) a ";
        sqlStmt += "where a.cnt >= 1) ";
        return jt.queryForList(sqlStmt);
    }
    public void adminBlogDelete(String seq){
        String sqlStmt1 = "delete from board where seq = ?";
        String sqlStmt2 = "delete from comment where board_id = ?";
        jt.update(sqlStmt1,seq);
        jt.update(sqlStmt2,seq);
    }
}
