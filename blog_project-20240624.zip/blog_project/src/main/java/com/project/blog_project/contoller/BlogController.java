package com.project.blog_project.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.blog_project.dao.BlogDao;
import com.project.blog_project.utility.Utility;

import jakarta.servlet.http.HttpSession;

import java.util.*;

@Controller
public class BlogController {
    @Autowired
    BlogDao blogDao;
    
    @GetMapping("blog/insert")
    public String blogInsert(Model model, 
                             HttpSession session){
        if(session.getAttribute("memberId").equals(null)){
            return "redirect:/member/login";
        }
        if(session.getAttribute("memberLevel").toString().equals("0")){
            return "redirect:/member/fail";
        }
        List<Map<String,Object>> codeList = blogDao.codeSelect();
        model.addAttribute("codeList", codeList);
        return "blog/insert";
    }
    @PostMapping("blog/insert/action")
    public String blogInsertAction(@RequestParam String subject,
                                   @RequestParam String title,
                                   @RequestParam String content,
                                   HttpSession session)
    {
        String memberId = session.getAttribute("memberId").toString();
        blogDao.insert(subject,title,content,memberId);
        return "blog/list";
    }
    @GetMapping("blog/list")
    public String blogList(Model model){
        List<Map<String,Object>> resultSet = blogDao.select();
        model.addAttribute("resultSet", resultSet);
        return "blog/list";
    }
    @GetMapping("blog/detail")
    public String blogDetail(Model model,@RequestParam String seq){
        Utility util = new Utility();
        List<Map<String,Object>> resultSet = blogDao.detail(seq);
        List<Map<String,Object>> detailResultSet = blogDao.detailComment(seq);
        List<String> regDtTime = new ArrayList<>();
        List<String> modifyDtTime = new ArrayList<>(); 
        System.out.println(resultSet.size());
        for(int i=0; i < resultSet.size(); i++){
            String regDt = resultSet.get(i).get("regDt").toString();
            String modifyDt = resultSet.get(i).get("modifyDt").toString();
            regDtTime.add(util.timeSubstring(regDt));
            modifyDtTime.add(util.timeSubstring(modifyDt));
        }

        model.addAttribute("resultSet", resultSet);
        model.addAttribute("regDtTime", regDtTime);
        model.addAttribute("modifyDtTime", modifyDtTime);
        model.addAttribute("detailResultSet", detailResultSet);
        
        return "blog/detail";
    }
    @PostMapping("blog/comment/insert")
    public String blogCommentInsert(@RequestParam String boardId,
                                    @RequestParam String comment,
                                    @RequestParam String memberId){
        blogDao.commentInsert(boardId,comment,memberId);
        String redirectURI = "/blog/detail?seq="+boardId;
        return "redirect:"+redirectURI;
    }
    @GetMapping("blog/update")
    public String blogUpdate(@RequestParam String seq, Model model){
        List<Map<String,Object>> resultSet = blogDao.detail(seq);
        List<Map<String,Object>> codeList = blogDao.codeSelect();
        model.addAttribute("resultSet", resultSet);
        model.addAttribute("codeList", codeList);
        return "blog/update";
    }
    @PostMapping("blog/update/action")
    public String blogUpdateAction(@RequestParam String seq,
                                   @RequestParam String subject,
                                   @RequestParam String title,
                                   @RequestParam String content){
        Utility util = new Utility();
        String currentDate = util.currentTime();
        blogDao.update(seq, subject, title, content, currentDate);
        String redirectURI = "redirect:/blog/detail?seq="+seq;
        return redirectURI;
    }
    @GetMapping("blog/search/subject")
    public String blogSearchSubject(@RequestParam String subject, Model model){
        List<Map<String,Object>> resultSet = blogDao.searchSubject(subject);

        model.addAttribute("resultSet", resultSet);
        return "blog/list";
    }
    @GetMapping("blog/search/content")
    public String blogSearchContent(@RequestParam String q, Model model){
        List<Map<String,Object>> resultSet = blogDao.searchContent(q);;
        model.addAttribute("resultSet", resultSet);
        return "blog/list";
    }
    @GetMapping("blog/order")
    public String blogOrder(@RequestParam String order, Model model){
        String orderMethod = "";
        if(order.equals("1")){
            orderMethod = "desc";
        }else {
            orderMethod = "asc";
        }
        List<Map<String, Object>> resultSet = blogDao.order(orderMethod);
        model.addAttribute("resultSet", resultSet);
        return "blog/list";
    }
    @GetMapping("blog/like")
    public String like(@RequestParam String seq, Model model){
        blogDao.like(seq);
        List<Map<String, Object>> resultSet = blogDao.select();
        model.addAttribute("resultSet", resultSet);
        return "blog/list";
    }
    @GetMapping("blog/delete")
    public String blogDelete(@RequestParam String seq, Model model){
        blogDao.delete(seq);
        List<Map<String, Object>> resultSet = blogDao.select();
        model.addAttribute("resultSet", resultSet);
        return "blog/list";
    }
    @GetMapping("blog/dislike")
    public String blogDislike(@RequestParam String seq, Model model){
        blogDao.dislike(seq);
        List<Map<String,Object>> resultSet = blogDao.select();
        model.addAttribute("resultSet", resultSet);
        return "blog/list";
    }

}