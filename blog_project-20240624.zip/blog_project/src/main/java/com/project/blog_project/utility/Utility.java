package com.project.blog_project.utility;
import java.util.*;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.time.LocalDateTime;

public class Utility {
    
    public String timeSubstring(String regDt){
       String year = regDt.substring(0, 10);
       String time = regDt.substring(11, 16);
       String yearTime = year+" "+time;
       return yearTime;   
    }
    public String currentTime(){
        String currentDate = LocalDateTime.now().toString();
        return currentDate;
    }    
}
