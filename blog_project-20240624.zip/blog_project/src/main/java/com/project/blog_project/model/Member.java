package com.project.blog_project.model;

import lombok.Data;

@Data
public class Member {
    private String memberId;
    private String memberNm;
    private String memberEmail;
    private String memberLevel;
}
