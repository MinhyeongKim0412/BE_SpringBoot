package com.project.blog_project.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.blog_project.dao.MemberDao;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import java.util.*;
import com.project.blog_project.dao.BlogDao;
import com.project.blog_project.dao.AdminDao;

@Controller
public class AdminController {
    @Autowired
    MemberDao memberDao;
    @Autowired
    BlogDao blogDao;
    @Autowired
    AdminDao adminDao;
    @GetMapping("admin/member")
    public String memberList(Model model, HttpSession session, HttpServletRequest request){
      
        if(session.getAttribute("memberLevel").equals(null)){
            session.setAttribute("memberLevel", "-1");
        }

        if(session.getAttribute("memberLevel").toString().equals("2")){
            List<Map<String,Object>> resultSet = memberDao.memberSelect();
            model.addAttribute("resultSet", resultSet);
            return "admin/member_list";
        }else {
            return "redirect:/member/login";
        }
  
    }
    @GetMapping("admin/member/update")
    public String memberUpdate(@RequestParam String memberId){
        memberDao.update(memberId);
        return "redirect:/admin/member";
    }
    @GetMapping("admin/member/delete")
    public String memberDelete(@RequestParam String memberId){
        memberDao.delete(memberId);
        return "redirect:/admin/member"; 
        //delete from member where member_id = ? 1, update member set del_fg = 1 where member_id = ?
    }
    @GetMapping("admin/blog")
    public String adminBlog(Model model){
        model.addAttribute("resultSet", blogDao.adminDeltetList());
        return "admin/blog";
    }
    @GetMapping("admin/blog/delete")
    public String adminBlogDelete(@RequestParam List<String> seqs){
        for(int i=0; i < seqs.size(); i++){
            String seq = seqs.get(i);
            blogDao.adminBlogDelete(seq);
        }
        return "redirect:/admin/member_list";
    }
    @GetMapping("admin/code")
    public String adminCodeList(Model model){
        List<Map<String,Object>> resultSet = adminDao.codeSelect();
        List<Map<String,Object>> resultCodeStat = adminDao.selectCodeStat();

        
        List<Map<String,Object>> codeStat = new ArrayList<>();
        
        for(int i=0; i<resultCodeStat.size();i++){
            Map<String,Object> codeContent = new HashMap<>();
            codeContent.put("codeStat",i);
            codeContent.put("codeNm",resultCodeStat.get(i).get("codeNm"));
            codeStat.add(codeContent);
        }
        model.addAttribute("resultSet", resultSet);
        model.addAttribute("codeStat", codeStat);
        model.addAttribute("resultCodeStat", resultCodeStat);
        return "admin/code/list";
    }
    @GetMapping("admin/code/insert")
    public String adminCodeInsert(Model model){
        List<Map<String,Object>> resultSet = adminDao.codeCategorySelect();
        model.addAttribute("resultSet", resultSet);
        return "admin/code/insert";
    }
    @GetMapping("admin/code/insert/action")
    public String adminCodeInsertAction(@RequestParam String category,
                                        @RequestParam String codeNm,
                                        @RequestParam String codeDesc){
            int codeDupCheckNo = adminDao.codeDupCheck(codeNm);
            if(codeDupCheckNo > 0){
                return "redirect:/admin/code/err";
            }                                 
            int categoryCnt = adminDao.idSelect(category)+1;

            String codeId = category+"_00"+categoryCnt;
            adminDao.codeInsert(category,codeId,codeNm,codeDesc);
        return "redirect:/admin/code";                           
    }
    @GetMapping("admin/code/stat")
    public String adminCodeStat(@RequestParam String seq,
                                @RequestParam String stat){
        adminDao.codeStatUpdate(seq,stat);
        return "redirect:/admin/code";
    }
    @GetMapping("admin/code/update")
    public String adminCodeUpdate(@RequestParam String seq,Model model){
        List<Map<String,Object>> resultCodeStat = adminDao.selectCodeStat();
        List<Map<String,Object>> codeStat = new ArrayList<>();
        List<Map<String,Object>> resultCodeCategory = adminDao.selectCodeCategory();
        for(int i=0; i<resultCodeStat.size();i++){
            Map<String,Object> codeContent = new HashMap<>();
            codeContent.put("codeStat",i);
            codeContent.put("codeNm",resultCodeStat.get(i).get("codeNm"));
            codeStat.add(codeContent);
        }

        List<Map<String,Object>> resultSet = adminDao.codeUpdateForSelect(seq);
        model.addAttribute("resultSet", resultSet);
        model.addAttribute("codeStat", codeStat);
        model.addAttribute("resultCodeCategory", resultCodeCategory);
        return "admin/code/update";
    }
    @GetMapping("admin/code/update/action")
    public String adminCodeUpdateAction(@RequestParam String seq,
                                        @RequestParam String stat,
                                        @RequestParam String codeNm,
                                        @RequestParam String codeDesc,
                                        @RequestParam String codeCat){
        adminDao.adminCodeUpdateAction(seq,stat,codeNm,codeDesc,codeCat);
        return "redirect:/admin/code";
   }
   @GetMapping("admin/code/category/insert")
   public String adminCodeCategoryInsert(Model model){
        return "admin/code/category";
   }
   @GetMapping("admin/code/category/insert/action")
   public String adminCodeCategoryInsertAction(@RequestParam String category){
    int categoryId = adminDao.categoryCnt()+1;
    adminDao.adminCodeCategoryInsertAction(categoryId,category);
    return "redirect:/admin/code";
   }
}    

