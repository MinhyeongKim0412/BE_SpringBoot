package com.project.blog_project.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import java.util.*;
import com.project.blog_project.dao.TestDao;

import jakarta.servlet.http.HttpSession;

@Controller
public class HtmlController {
    @GetMapping("/main")
    public String main(HttpSession session){
        String memberLevel = session.getAttribute("memberLevel").toString();
        System.out.println("memberLevl:  "+memberLevel);
        System.out.println("memberId:  "+session.getAttribute("memberId"));
        System.out.println(memberLevel.equals("2"));
        if(session.getAttribute("memberId").equals("null")){
            return "redirect:/member/login";
        }
        if(memberLevel.equals("2")){
            return "redirect:/admin/member";
        }else {
            return "main";
        }
    }
}
