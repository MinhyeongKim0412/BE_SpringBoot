package com.project.blog.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.project.blog.dao.ZipcodeDao;
import java.util.*;


@Controller
public class HtmlController {
    @Autowired
    ZipcodeDao zipcodeDao;
    @GetMapping("/")
    public String index(){
        return "index";
    }
    @GetMapping("util/search")
    public String utilSearch(){
        return "util/search";
    }
    @PostMapping("util/search")
    public String utilSearchAction(@RequestParam String q, Model model){
        List<Map<String,Object>> resultSet = zipcodeDao.seachZipcode(q);
        model.addAttribute("resultSet", resultSet);
        return "util/search";
    }
}
